-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2024 at 04:05 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `we-aims`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `fname`, `lname`, `email`, `password`) VALUES
(1, 'Emman', 'Nieva', 'em@gmail.com', '12345678'),
(2, 'Juan', 'Dela Cruz', 'juan@gmail.com', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `paymentMethod` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `firstName`, `lastName`, `phone`, `paymentMethod`) VALUES
(27, 'Pia', 'Lim', '09123456789', 'Cash'),
(28, 'Jeremy', 'Miller', '09128654321', 'Cash'),
(29, 'Steven', 'Holmes', '09955486321', 'Credit Card'),
(30, 'Charlie', 'Monroe', '09656840123', 'Cash'),
(31, 'Fiona', 'Smith', '09068563765', 'Credit Card');

-- --------------------------------------------------------

--
-- Table structure for table `deleted_customers`
--

CREATE TABLE `deleted_customers` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `paymentMethod` varchar(50) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deleted_customers`
--

INSERT INTO `deleted_customers` (`id`, `customer_id`, `firstName`, `lastName`, `phone`, `paymentMethod`, `deleted_at`) VALUES
(36, 25, 'Ian Gabriel', 'Villame', '09997135311', 'Credit Card', '2024-05-17 06:59:56');

-- --------------------------------------------------------

--
-- Table structure for table `deleted_employees`
--

CREATE TABLE `deleted_employees` (
  `employee_id` int(11) NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `phone_no` varchar(15) DEFAULT NULL,
  `deleted_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deleted_products`
--

CREATE TABLE `deleted_products` (
  `productId` int(11) NOT NULL,
  `Sup_Id` int(11) DEFAULT NULL,
  `companyName` varchar(255) DEFAULT NULL,
  `productName` varchar(255) DEFAULT NULL,
  `costPrice` decimal(10,2) DEFAULT NULL,
  `retailPrice` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `deleted_at` datetime DEFAULT current_timestamp(),
  `totalCostPrice` decimal(10,2) DEFAULT NULL,
  `totalRetailPrice` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deleted_services`
--

CREATE TABLE `deleted_services` (
  `serviceId` int(11) NOT NULL,
  `serviceName` varchar(255) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `employee_role` varchar(255) NOT NULL,
  `timeRequired` varchar(50) DEFAULT NULL,
  `servicePrice` decimal(10,2) DEFAULT NULL,
  `delete_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deleted_suppliers`
--

CREATE TABLE `deleted_suppliers` (
  `id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `companyName` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `zipCode` varchar(20) DEFAULT NULL,
  `phoneNumber` varchar(50) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deleted_transactions`
--

CREATE TABLE `deleted_transactions` (
  `transactionId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `date` datetime DEFAULT NULL,
  `productName` varchar(255) DEFAULT NULL,
  `retailPrice` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `totalRetailPrice` decimal(10,2) DEFAULT NULL,
  `customerName` varchar(255) DEFAULT NULL,
  `paymentMethod` varchar(50) DEFAULT NULL,
  `deleted_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deleted_transactionsser`
--

CREATE TABLE `deleted_transactionsser` (
  `transactionServiceId` int(11) NOT NULL,
  `serviceId` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `employeeId` int(11) NOT NULL,
  `date` date NOT NULL,
  `serviceName` varchar(255) NOT NULL,
  `servicePrice` decimal(10,2) NOT NULL,
  `customerName` varchar(255) NOT NULL,
  `paymentMethod` varchar(100) NOT NULL,
  `employeeName` varchar(255) NOT NULL,
  `role` varchar(100) NOT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deleted_transactionsser`
--

INSERT INTO `deleted_transactionsser` (`transactionServiceId`, `serviceId`, `customerId`, `employeeId`, `date`, `serviceName`, `servicePrice`, `customerName`, `paymentMethod`, `employeeName`, `role`, `deleted_at`) VALUES
(57, 26, 26, 11, '2024-05-17', 'Tire Mounting and Balancing', 500.00, 'Ian Gabriel', 'Cash', 'Vicente', 'Installation Technician', '2024-05-17 07:10:31');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `employee_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `salary` decimal(10,2) NOT NULL,
  `phone_no` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employee_id`, `first_name`, `last_name`, `role`, `salary`, `phone_no`) VALUES
(12, 'Ronald', 'Jasareno', 'Marketing and Sales Manager', 25000.00, '09097507203'),
(13, 'Kim', 'Opeña', 'Sales Associate', 23000.00, '09123456789'),
(14, 'Richard', 'Moral', 'Installation Technician', 10000.00, '09987654321'),
(15, 'Joshua', 'Dones', 'Sales Associate', 21000.00, '09242834392'),
(16, 'Maria', 'Santos', 'Inventory Manager', 24000.00, '09178887055');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `productId` int(11) NOT NULL,
  `Sup_Id` int(11) DEFAULT NULL,
  `companyName` varchar(255) DEFAULT NULL,
  `productName` varchar(255) DEFAULT NULL,
  `costPrice` decimal(10,2) DEFAULT NULL,
  `retailPrice` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `totalCostPrice` decimal(10,2) DEFAULT NULL,
  `totalRetailPrice` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`productId`, `Sup_Id`, `companyName`, `productName`, `costPrice`, `retailPrice`, `quantity`, `totalCostPrice`, `totalRetailPrice`, `created_at`, `updated_at`) VALUES
(84, 18, 'Car Mechanics South Border', 'Car Battery', 2000.00, 3000.00, 50, 100000.00, 175000.00, '2024-05-17 15:39:25', '2024-05-17 15:39:25'),
(85, 19, 'North Cameron Braking Pads', 'Brake Pads', 1200.00, 1800.00, 100, 120000.00, 180000.00, '2024-05-17 15:39:25', '2024-05-17 15:39:25'),
(86, 20, 'China Oil Cooperatives', 'Engine Oil', 150.00, 300.00, 200, 30000.00, 60000.00, '2024-05-17 15:39:25', '2024-05-17 15:39:25'),
(87, 21, 'Air na Mo Supplier', 'Air Filter', 400.00, 700.00, 80, 32000.00, 56000.00, '2024-05-17 15:39:25', '2024-05-17 15:39:25'),
(88, 22, 'Tires Tires Baby', 'Tires', 2000.00, 3500.00, 50, 100000.00, 175000.00, '2024-05-17 15:39:25', '2024-05-17 15:39:25');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `serviceId` int(11) NOT NULL,
  `serviceName` varchar(255) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `employee_role` varchar(255) NOT NULL,
  `timeRequired` varchar(255) NOT NULL,
  `servicePrice` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`serviceId`, `serviceName`, `employee_id`, `employee_name`, `employee_role`, `timeRequired`, `servicePrice`) VALUES
(42, 'Tire Mounting and Balancing', 14, 'Richard Moral', 'Installation Technician', '30 minutes', 500.00),
(43, 'Brake Pad Replacement', 14, 'Richard Moral', 'Installation Technician', '1 hour', 1500.00),
(44, 'Battery Installation', 14, 'Richard Moral', 'Installation Technician', '20 minutes', 300.00),
(45, 'Oil Change', 14, 'Richard Moral', 'Installation Technician', '45 minutes', 1000.00),
(46, 'Air Filter Replacement', 14, 'Richard Moral', 'Installation Technician', '15 minutes', 300.00);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `Sup_Id` int(11) NOT NULL,
  `companyName` varchar(255) NOT NULL,
  `province` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `zipCode` varchar(20) DEFAULT NULL,
  `phoneNumber` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`Sup_Id`, `companyName`, `province`, `city`, `zipCode`, `phoneNumber`) VALUES
(18, 'Car Mechanics South Border', 'Bulacan', 'Santa Maria', '3022', '09123960034'),
(19, 'North Cameron Braking Pads', 'Laguna', 'Santa Rosa City', '4000', '09169454712'),
(20, 'China Oil Cooperatives', 'Albay', 'Legazpi City', '4500', '09953322115'),
(21, 'Air na Mo Supplier', 'Camarines Sur', 'Pili', '4418', '09957879009'),
(22, 'Tires Tires Baby', 'Sorsogon', 'Barcelona', '4712', '09651212370');

--
-- Triggers `suppliers`
--
DELIMITER $$
CREATE TRIGGER `update_product_companyName` AFTER UPDATE ON `suppliers` FOR EACH ROW BEGIN
    UPDATE products
    SET companyName = NEW.companyName
    WHERE Sup_Id = NEW.Sup_Id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `transactionspro`
--

CREATE TABLE `transactionspro` (
  `transactionId` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `productId` int(11) DEFAULT NULL,
  `productName` varchar(255) DEFAULT NULL,
  `retailPrice` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `totalRetailPrice` decimal(10,2) DEFAULT NULL,
  `customerId` int(11) DEFAULT NULL,
  `customerName` varchar(255) DEFAULT NULL,
  `paymentMethod` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactionspro`
--

INSERT INTO `transactionspro` (`transactionId`, `date`, `productId`, `productName`, `retailPrice`, `quantity`, `totalRetailPrice`, `customerId`, `customerName`, `paymentMethod`) VALUES
(42, '2024-05-17', 84, 'Car Battery', 3000.00, 2, 6000.00, 27, 'Pia', 'Cash'),
(43, '2024-05-18', 85, 'Brake Pads', 1800.00, 3, 5400.00, 28, 'Jeremy Miller', 'Cash'),
(44, '2024-05-19', 86, 'Engine Oil', 300.00, 1, 300.00, 29, 'Steven Holmes', 'Credit Card'),
(45, '2024-05-20', 87, 'Air Filter', 700.00, 3, 2100.00, 30, 'Charlie Monroe', 'Cash'),
(46, '2024-05-21', 88, 'Tires', 3500.00, 2, 7000.00, 31, 'Fiona Smith', 'Credit Card');

-- --------------------------------------------------------

--
-- Table structure for table `transactionsser`
--

CREATE TABLE `transactionsser` (
  `transactionServiceId` int(11) NOT NULL,
  `date` date NOT NULL,
  `serviceId` int(11) NOT NULL,
  `serviceName` varchar(255) NOT NULL,
  `servicePrice` decimal(10,2) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customerName` varchar(255) NOT NULL,
  `paymentMethod` varchar(100) NOT NULL,
  `employeeId` int(11) NOT NULL,
  `employeeName` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactionsser`
--

INSERT INTO `transactionsser` (`transactionServiceId`, `date`, `serviceId`, `serviceName`, `servicePrice`, `customerId`, `customerName`, `paymentMethod`, `employeeId`, `employeeName`, `role`) VALUES
(58, '2024-05-17', 42, 'Tire Mounting and Balancing', 500.00, 27, 'Pia Lim', 'Cash', 14, 'Richard Moral', 'Installation Technician'),
(59, '2024-05-18', 43, 'Brake Pad Replacement', 1500.00, 28, 'Jeremy Miller', 'Cash', 14, 'Richard Moral', 'Installation Technician'),
(60, '2024-05-19', 44, 'Battery Installation', 300.00, 29, 'Steven Holmes', 'Credit Card', 15, 'Joshua Dones', 'Sales Associate'),
(61, '2024-05-20', 45, 'Oil Change', 1000.00, 30, 'Charlie Monroe', 'Cash', 14, 'Richard Moral', 'Installation Technician'),
(62, '2024-05-21', 46, 'Air Filter replacement', 300.00, 31, 'Fiona Smith', 'Credit Card', 14, 'Richard Moral', 'Installation Technician');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deleted_customers`
--
ALTER TABLE `deleted_customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deleted_employees`
--
ALTER TABLE `deleted_employees`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `deleted_products`
--
ALTER TABLE `deleted_products`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `deleted_services`
--
ALTER TABLE `deleted_services`
  ADD PRIMARY KEY (`serviceId`);

--
-- Indexes for table `deleted_suppliers`
--
ALTER TABLE `deleted_suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deleted_transactions`
--
ALTER TABLE `deleted_transactions`
  ADD PRIMARY KEY (`transactionId`);

--
-- Indexes for table `deleted_transactionsser`
--
ALTER TABLE `deleted_transactionsser`
  ADD PRIMARY KEY (`transactionServiceId`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`productId`),
  ADD KEY `Sup_Id` (`Sup_Id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`serviceId`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`Sup_Id`);

--
-- Indexes for table `transactionspro`
--
ALTER TABLE `transactionspro`
  ADD PRIMARY KEY (`transactionId`),
  ADD KEY `customerId` (`customerId`),
  ADD KEY `transactionspro_ibfk_1` (`productId`);

--
-- Indexes for table `transactionsser`
--
ALTER TABLE `transactionsser`
  ADD PRIMARY KEY (`transactionServiceId`),
  ADD KEY `serviceId` (`serviceId`),
  ADD KEY `customerId` (`customerId`),
  ADD KEY `employeeId` (`employeeId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `deleted_customers`
--
ALTER TABLE `deleted_customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `deleted_suppliers`
--
ALTER TABLE `deleted_suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `serviceId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `Sup_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `transactionspro`
--
ALTER TABLE `transactionspro`
  MODIFY `transactionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `transactionsser`
--
ALTER TABLE `transactionsser`
  MODIFY `transactionServiceId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `services_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`);

--
-- Constraints for table `transactionspro`
--
ALTER TABLE `transactionspro`
  ADD CONSTRAINT `transactionspro_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `products` (`productId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transactionspro_ibfk_2` FOREIGN KEY (`customerId`) REFERENCES `customers` (`id`);

--
-- Constraints for table `transactionsser`
--
ALTER TABLE `transactionsser`
  ADD CONSTRAINT `transactionsser_ibfk_1` FOREIGN KEY (`serviceId`) REFERENCES `services` (`serviceId`),
  ADD CONSTRAINT `transactionsser_ibfk_2` FOREIGN KEY (`customerId`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `transactionsser_ibfk_3` FOREIGN KEY (`employeeId`) REFERENCES `employees` (`employee_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
